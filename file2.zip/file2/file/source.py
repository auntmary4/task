import json
import random
import os
from datetime import datetime, timedelta
import time
import sched

class Article:
    def __init__(self, title, body, author):
        self.title = title
        self.body = body
        self.author = author
        self.datetime = datetime.now().strftime("%A %d-%b-%Y %H:%M:%S") 
        self.likes = random.randint(10, 100)

# Предустановленные шаблоны для заголовков
TITLES = [
    "Как стать успешным",
    "Топ 10 советов по программированию",
    "Путешествие по России: лучшие места",
    "Здоровое питание: мифы и реальность",
    "История технологий: от древности до наших дней"
]

_I = 5
_TIME_SEC = 10
_LOG_DIR = 'json/log'
_LOG_FILE = f'{_LOG_DIR}/serialize-{datetime.now().strftime("%Y%m%d")}.log'
_JSON_DIR = 'json/download'

# Создаем директории для логов и JSON-файлов, если они не существуют
os.makedirs(_LOG_DIR, exist_ok=True)
os.makedirs(_JSON_DIR, exist_ok=True)

def log(s):
    with open(_LOG_FILE, "a", encoding='utf-8') as f:
        f.writelines(f'{datetime.now().strftime("%H:%M:%S")} | {s} \n')


def to_dict(o):
    result = o.__dict__
    result["className"] = o.__class__.__name__
    return result


def generate_title():
    return random.choice(TITLES)


def send_json_data(i):
    try:
        title = generate_title()
        body = f'Содержание статьи {i}: Некоторый текст с уникальным номером - {random.randint(1000, 9999999)}'
        author = f'Автор {random.randint(1, 10)}'  # Пример автора
        art = Article(title, body, author)
        fd = f'{_JSON_DIR}/{i}-{datetime.now().strftime("%Y%m%d%H%M%S")}-data.json'
        with open(fd, "x", encoding='utf-8') as f:
            json.dump(art, f, default=to_dict, ensure_ascii=False)
        log(f'Отправка {i} выполнена')
    except Exception as err:
        log(f'Ошибка отправки {i} - {err}')


def display_articles():
    print("Список созданных статей:")
    for filename in os.listdir(_JSON_DIR):
        if filename.endswith('.json'):
            with open(os.path.join(_JSON_DIR, filename), 'r', encoding='utf-8') as f:
                article = json.load(f)
                print(f"Заголовок: {article['title']}, Автор: {article['author']}, Дата: {article['datetime']}, Лайки: {article['likes']}")


def delete_old_json_files(days=7):
    threshold_date = datetime.now() - timedelta(days=days)
    for filename in os.listdir(_JSON_DIR):
        file_path = os.path.join(_JSON_DIR, filename)
        if filename.endswith('.json'):
            file_creation_time = datetime.fromtimestamp(os.path.getctime(file_path))
            if file_creation_time < threshold_date:
                os.remove(file_path)
                log(f'Удален старый файл: {filename}')


_J = 0
def do_work(sc): 
    global _J
    _J += 1
    print(f'--- {_J} ---')
    send_json_data(_J)
    if _J < _I:
        s.enter(_TIME_SEC, 1, do_work, (sc,))
    else:
        display_articles()
        delete_old_json_files()

log("-= START =-")
s = sched.scheduler(time.time, time.sleep)
s.enter(1, 1, do_work, (s,))
s.run()
log("-= STOP =-")
